/*  ogkU_C: OGK scatter matrix U using MAD as scale estimator.
 *
 *  U[i,j] = (MAD(Yi+Yj)^2 - MAD(Yi-Yj)^2) / 4
 *
 *  MAD = median(|x - median(x)|)  [without consistency constant —
 *  it cancels in eigenvectors, which is all we need downstream].
 *
 *  Complexity per pair: 2 * O(n log n)  vs  Qn's O(n log n + 60n).
 *  For n=100: ~1500 ops vs ~6700  =>  ~4.5x faster than binary-search Qn.
 *
 *  Breakdown point: 50% (same as Qn).
 *  Efficiency vs Qn: lower (37% vs 82%), but sufficient for starting-
 *  point quality in MRCD C-steps.
 *
 *  Pairs are parallelised with OpenMP when available.
 */

#ifdef _OPENMP
#include <omp.h>
#endif

#include <R.h>
#include <Rinternals.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

static int cmp_double(const void *a, const void *b) {
    double da = *(const double *)a;
    double db = *(const double *)b;
    return (da > db) - (da < db);
}

/* Raw MAD = median(|x - median(x)|)  — no consistency constant needed */
static double mad_raw(const double *col, int n, double *buf) {
    memcpy(buf, col, n * sizeof(double));
    qsort(buf, n, sizeof(double), cmp_double);

    /* median of sorted array */
    double med = (n % 2 == 0)
        ? (buf[n/2 - 1] + buf[n/2]) * 0.5
        :  buf[n/2];

    /* absolute deviations, then sort them */
    for (int i = 0; i < n; i++) buf[i] = fabs(buf[i] - med);
    qsort(buf, n, sizeof(double), cmp_double);

    return (n % 2 == 0)
        ? (buf[n/2 - 1] + buf[n/2]) * 0.5
        :  buf[n/2];
}

/* .Call entry: ogkU_C(Y, n, p)
 *   Y : n x p matrix (column-major double)
 *   n, p : integer scalars
 *   returns: p x p symmetric U matrix
 */
SEXP ogkU_C(SEXP Y_sexp, SEXP n_sexp, SEXP p_sexp) {
    int n = asInteger(n_sexp);
    int p = asInteger(p_sexp);
    double *Y = REAL(Y_sexp);

    SEXP U_sexp = PROTECT(allocMatrix(REALSXP, p, p));
    double *U   = REAL(U_sexp);

    for (int i = 0; i < p * p; i++) U[i] = 0.0;
    for (int i = 0; i < p;     i++) U[i + i * p] = 1.0;

#ifdef _OPENMP
#pragma omp parallel
    {
#else
    {
#endif
        double *sump = (double *) malloc(n * sizeof(double));
        double *difp = (double *) malloc(n * sizeof(double));
        double *bs   = (double *) malloc(n * sizeof(double));
        double *bd   = (double *) malloc(n * sizeof(double));

#ifdef _OPENMP
#pragma omp for schedule(dynamic, 4)
#endif
        for (int ci = 1; ci < p; ci++) {
            const double *colI = Y + (long)ci * n;
            for (int cj = 0; cj < ci; cj++) {
                const double *colJ = Y + (long)cj * n;
                for (int r = 0; r < n; r++) {
                    sump[r] = colI[r] + colJ[r];
                    difp[r] = colI[r] - colJ[r];
                }
                double ms = mad_raw(sump, n, bs);
                double md = mad_raw(difp, n, bd);
                double cov_ij = (ms * ms - md * md) / 4.0;
                U[ci + (long)cj * p] = cov_ij;
                U[cj + (long)ci * p] = cov_ij;
            }
        }

        free(sump); free(difp); free(bs); free(bd);
    }

    UNPROTECT(1);
    return U_sexp;
}
